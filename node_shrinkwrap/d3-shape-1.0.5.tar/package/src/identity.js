export default function(d) {
  return d;
}

export {default as voronoi} from "./src/voronoi";

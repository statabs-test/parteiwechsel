import transpose from "./transpose";

export default function() {
  return transpose(arguments);
}

var array = Array.prototype;

export var slice = array.slice;
export var map = array.map;
